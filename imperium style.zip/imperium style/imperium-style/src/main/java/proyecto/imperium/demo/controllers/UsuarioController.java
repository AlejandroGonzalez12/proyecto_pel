package proyecto.imperium.demo.controllers;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import proyecto.imperium.demo.Service.usuarioService;
import proyecto.imperium.demo.models.Usuario;
import proyecto.imperium.demo.repo.UsuarioRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class UsuarioController {

    @Autowired
    private UsuarioRepo usuarioRepo;

    @GetMapping("/" + ""+ "index.html")
    public String verIndex(Model modelo) {
        List<Usuario> usuario = usuarioRepo.findAll();
        modelo.addAttribute("usuario", usuario);
        return "index";
    }

    @GetMapping("/portfolio-details.html")
    public String verPortfolio() {
        return "portfolio-details";
    }

    @GetMapping("/sign_up.html")
    public String verFormRegistro(Model modelo) {
        modelo.addAttribute("usuario", new Usuario());
        return "sign_up";
    }

    @PostMapping("/sign_up.html")
    public String guardarUsuario(@Validated Usuario usuario, BindingResult bindingResult, RedirectAttributes redirect, Model modelo){
        if (bindingResult.hasErrors()){
            modelo.addAttribute("usuario", usuario);
        }
        usuarioRepo.save(usuario);
        redirect.addFlashAttribute("msgExito", "El usuario ha sido registrado con éxito");
        return "redirect:/";
    }

    @Autowired
    private usuarioService service;
        @GetMapping("/tablas")
        public String listUsers(Model model) {
        model.addAttribute("usuario", service.listAllUsers());
            return "tablas";
        }

    @GetMapping("/{id}/editar")
    public String verFormDeEdicion (@PathVariable Integer id, Model modelo) {
        Usuario usuario = usuarioRepo.findById(id).orElseThrow();
        new IllegalArgumentException("Usuario inválido con id: " + id);
        modelo.addAttribute("usuario", usuario);
        return "editar_us";
    }

    @PostMapping("/{id}/editar")
    public String actualizarUsuario(@PathVariable Integer id, @Validated Usuario usuario, BindingResult bindingResult, RedirectAttributes redirect, Model modelo){
        Usuario usuarioDB = usuarioRepo.findById(Integer.parseInt(String.valueOf(id))).orElseThrow();
        if (bindingResult.hasErrors()){
            modelo.addAttribute("usuario", usuario);
            return "editar_us";
        }
        usuarioDB.setNombre(usuario.getNombre());
        usuarioDB.setEmail(usuario.getEmail());
        usuarioDB.setTelefono(usuario.getTelefono());

        usuarioRepo.save(usuario);
        redirect.addFlashAttribute("msgExito", "El usuario ha sido actualizado con éxito");
        return "redirect:/tablas";
    }


}
