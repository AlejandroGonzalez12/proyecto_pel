package proyecto.imperium.demo.Service;
import java.util.List;
import java.util.Optional;

import proyecto.imperium.demo.models.Usuario;

public interface usuarioService {

    public List<Usuario>listAllUsers();
    public Optional<Usuario>getUsuarioById(Integer id);
}
