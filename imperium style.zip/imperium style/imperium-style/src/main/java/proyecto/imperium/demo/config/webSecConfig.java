/*package proyecto.imperium.demo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;

@Configuration
public class webSecConfig {

    @Bean
    public userDetailsService userDetailsService(){
        return new userDetailsService();
    }
}
*/